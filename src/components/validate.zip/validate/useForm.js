import { useState, useEffect } from "react";


const useForm = (validate) => {
    const [ details] = useState({});
    var [data,setData]=useState()
    const [formValues, setFormValues] = useState(details);
    const [formErrors, setFormErrors] = useState({});
    const [isSubmit, setIsSubmit] = useState(false);
  

    const handleChange = (e,name) => {
    // const { name, value } = e.target;
    console.log(formValues);
    setFormValues({ ...formValues, [name]:e});

  };

    const handleSubmit = (e) => {
 
    e.preventDefault();
    console.log(formValues,'formValues');
    setFormErrors(validate(formValues));
    setIsSubmit(true);

    ;
  };

    useEffect(() => {
    console.log(formErrors),"errors";
    if (Object.keys(formErrors).length === 0 && isSubmit) {
        console.log(formValues,'formValues'); 
      setData(formValues);
    }
  },[formErrors]);
  

   return { handleChange, details, handleSubmit,formErrors,data}

}
export default useForm;